<?php
error_reporting(1);
mysql_connect("localhost","root","");
mysql_select_db("project");
?>