<html>
<body>
<div><center><h2><font face="Lucida Handwriting" size="+1" color="#00CCFF">WOMEN'S APPAREL</font></h2></center></div>
<div align="center">
<a href="PRIMER.php"><img src="images/primer.jpg"></a>
<a href="CONCEALER.php"><img src="images/consealer.jpg"></a>
<a href="MOISTURIZER.php"><img src="images/MOISTURIZER.jpg"></a><br>
<a href="FOUNDATION.php"><img src="images/FOUNDATION.jpg"></a>
<a href="EYEBROW_POMADE.php"><img src="images/EYEBROW_POMADE.jpg"></a>
<a href="SPOOLIE_BRUSH.php"><img src="SPOOLIE_BRUSH.jpg"></a>
<a href="EYELINER.php"><img src="images/EYELINER.jpg"></a>
<a href="MASCARA.php"><img src="images/MASCARA.jpg"></a>
<a href="LIPSTICK.php"><img src="images/LIPSTICK.jpg"></a>
<a href="BLUSH_HIGHLIGHTER.php"><img src="images/BLUSH_HIGHLIGHTER.jpg"></a>
<a href="EYESHADOW_PALETTE.php"><img src="images/EYESHADOW_PALETTE.jpg"></a>

</div>
</body>
</html>
