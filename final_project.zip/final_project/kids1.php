<html>
<body>
<div><center><h2>KIDS'S APPAREL</h2></center></div>
<div align="center">
<a href="LOTION.PHP"><img src="images/LOTION.jpg" width="769" height="328"></a><br>
<a href="CREAM.php"><img src="images/CREAM.jpg"></a>
<a href="POWDER.php"><img src="images/POWDER.jpg"></a>
<a href="OIL.php"><img src="images/OIL.jpg"></a>
</div>
</body>
</html>