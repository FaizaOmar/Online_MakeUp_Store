<html>
<head>
<link rel="stylesheet" href="/lib/w3.css"> 

<script>
function abc()
{
var arr=new Array("pic1.jpg","pic2.jpg","pic3.jpg","pic4.jpg","pic5.jpg");
var ind=eval(document.f1.h1.value);
document.img.src=arr[ind];
document.f1.h1.value=ind+1;
if(document.f1.h1.value==5)
{
document.f1.h1.value=0;
}
}
setInterval("abc()",3000);

</script>
</head>
<body>
<div id="RightPart">
  <div id="Page"><img src="pic1.jpg" alt="" width="670" height="300" name="img"/>
 

   <div id="down"><img src="p1.jpg" width="670" height="300"/>
               
                 <a href="tips.html"><img src="tips.jpg" alt="" width="100" height="100" ></a>
  <form name="f1">
  <input type="hidden" name="h1" value="0" />
  </form>
   </div>
    </div>
  </div>
  </div>
  </body>
</html>