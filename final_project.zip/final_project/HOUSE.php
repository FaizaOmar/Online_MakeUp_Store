<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cz"><head><title>FASHION SHOP</title>

<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<link rel="icon" href="favicon.ico" type="image/x-icon">
<link rel="stylesheet" type="text/css" href="default.css" title="default">
<script>
function abc()
{
var arr=new Array("pic1.jpg","pic2.jpg","pic3.jpg","pic4.jpg","pic5.jpg");
var ind=eval(document.f1.h1.value);
document.img.src=arr[ind];
document.f1.h1.value=ind+1;
if(document.f1.h1.value==5)
{
document.f1.h1.value=0;
}
}
setInterval("abc()",3000);
</script>
</head>



<body>

<div id="WholePage">
<div id="Inner">
<div id="Container" >
<div id="Head">
  <div id="Head_left">
    div id="Leaf_top"><img src="p1.jpg" width="200 px" /></div>
     <div id="Leaf_bottom"> <a class="registration" href="register.html">REGISTRATION</a> <a class="log-in" href="login.html">LOG IN</a> </div>
  </div>
  <div id="Head_right">
    <div id="Logo">
    <div id="Name"><span class="blue">I</span><span class="purple">n</span>&nbsp;<span class="blue">S</span><span class="purple">tyle</span> </div>
    <div id="Informations">Latest trends in Fashion</div>
  </div>
<div id="Top_menu"> <a class="kart" href="?page=home"><span>KART</span></a> 
<a class="video" href="video.html"><span>VIDEO</span></a>
<a class="contact" href="?page=home"><span>CONTACT</span></a>
<a class="help" href="about_us.html"><span>ABOUT_US</span></a>
<a class="home" href="?page=home"><span>HOME</span></a>
</div>
</div>
</div>
<div id="CentralPart">
<div id="LeftPart">
<div id="Menu">
<div id="Menu_header">
<div class="menu_header_left"> <span class="menu_text"><font face="Georgia, Times New Roman, Times, serif">Search</font></span>
</div>
<div class="menu_header_right"> </div>
<div id="Menu_content"> <!--<a class="menu_item" href="?page=home"><span>--><!-- Start of Page Search -->

		
		    <h5>&nbsp;</h5>
		    <input type="text" name="t1" value="search" onfocus=
"if(this.value=='search')
{this.value='';}
"
onBlur=
"if(this.value=='')
{this.value='search';}
"/>
            <input name="sub" type="submit" class="button" id="sub" value="Go" />

		

		  <h5>&nbsp;</h5>
		  <!--</form>-->
		

		<!-- End of Page Search --></span></a><br>
</div>
<div class="menu_header_left"> <span class="menu_text"><a href="men.html">MEN</a></span>
</div>
<div class="menu_header_right"> </div>
</div>
<div id="Menu_content"> <a class="menu_item" href="ANTI_AGING.php"><span>ANTI_AGING</span></a><br>
<a class="menu_item" href="CLEANSER.php"><span>CLEANSER</span></a><br>
<a class="menu_item" href="PRE_SHAVE.php"><span>PRE_SHAVE</span></a><br>
<a class="menu_item" href="SHAVE.php"><span>SHAVE</span></a><br>
<a class="menu_item" href="BODY_PRODUCT.php"><span>BODY_PRODUCT</span></a><br>
<a class="menu_item" href="HAIR_PRODUCT.php"><span>HAIR_PRODUCT</span></a><br>

</div>

<div class="menu_header_left"> <span class="menu_text"><a href="women1.html">WOMEN</a></span>
</div>
<div class="menu_header_right"> </div>
<div id="Menu_content"> <a class="menu_item" href="MOISTURIZER.php?catg=2 & subcatg=MOISTURIZER"><span>MOISTURIZER</span></a><br>
<a class="menu_item" href="PRIMER.php"><span>PRIMER</span></a><br>
<a class="menu_item" href="CONCEALER.php"><span>CONCEALER </span></a><br>
<a class="menu_item" href="FOUNDATION.php"><span>FOUNDATION</span></a><br>
<a class="menu_item" href="EYEBROW_POMADE.php"><span>EYEBROW POMADE</span></a><br>
<a class="menu_item" href="SPOOLIE_BRUSH.php"><span>SPOOLIE BRUSH</span></a><br>
<a class="menu_item" href="EYELINER.php"><span>EYELINER</span></a><br>
<a class="menu_item" href="MASCARA.php"><span>MASCARA </span></a><br>
<a class="menu_item" href="LIPSTICK.php"><span> LIPSTICK</span></a><br>
<a class="menu_item" href="BLUSH_HIGHLIGHTER.php"><span>BLUSH AND HIGHLIGHTER</span></a><br>
<a class="menu_item" href="EYESHADOW_PALETTE.php"><span>EYESHADOW PALETTE</span></a><br>
</div>

<div class="menu_header_left"> <span class="menu_text"><a href="kids1.html">KIDS</a></span>
</div>
<div class="menu_header_right"> </div>
<div id="Menu_content"> <a class="menu_item" href="LOTION.php"><span>LOTION</span></a><br>
<a class="menu_item" href="CREAM.php"><span>CREAM</span></a><br>
<a class="menu_item" href="POWDER.php"><span>POWDER & SOAP</span></a><br>
<a class="menu_item" href="OIL.php"><span>OIL & SHAMPOO</span></a><br>

</div>
</div>
<img src="pic1.jpg" width="228" height="183" /></div>
<!--<div id="Poll">
<div id="Poll_header">
<div class="menu_header_left"> <span class="menu_text">WOMEN</span>
</div>
<div class="menu_header_right"> </div>
</div>
<div id="Poll_content"> <span class="poll_question">Donec
at justo ac ipsum laoreet dapibus?</span><br>
<a class="poll_unswer" href="?page=home"><span>Lorem
ipsum</span></a><br>
<a class="poll_unswer" href="?page=home"><span>Nulla
facilisi</span></a><br>
<a class="poll_unswer" href="?page=home"><span>Suspendisse
ipsum</span></a><br>
</div>
</div>
<div id="Banner"> <img src="img/banner.jpg" alt="illustration image"> </div>
</div>-->
<div id="RightPart">
  <div id="Page"><img src="pic1.jpg" alt="" width="669" height="210" name="img"/>
  <form name="f1">
  <input type="hidden" name="h1" value="0" />
  </form>
    <div id="Page_top">
  <p> <marquee behavior="scroll" direction="left" onmouseover="stop()" onmouseout="start()"><font color="#FFFF99"><h3>30%off on all summer wear...Hurry!!!</h3></font><font color="#00CC99"><h4>Enjoy the pleasure of shopping with Fashion Shop...</h4></font></marquee><br> </p>
 </div>
  <div id="Page_center">
  
  </div>
</div></div>
<div class="cleaner"></div>
</div>
<div id="Bottom">
<p class="down">Copyright � IN STYLE, Design by:Faiza Omer & Sayeeda Saima Tulon</p>
</div>
</div>
</div>
</div>
</div>

</body></html>