<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="cz"><head>
<?php
error_reporting(1);

?>
<title>Company name - title</title>


<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<link rel="icon" href="favicon.ico" type="image/x-icon">

<link rel="stylesheet" type="text/css" href="default.css" title="default">

</head>


<body>

<div id="WholePage" >
 
   <div class="banner">
  <figure>
    <div class="banner-image">
        <img src="1.jpg">
   </div>
      <div class="banner-image">
         <img src="2.jpg">
   </div>
     <div class="banner-image">
         <img src="3.jpg">
    </div>
     <div class="banner-image">
         <img src="4.jpg">
    </div>
     <div class="banner-image">
         <img src="5.jpg">
    </div>
  </figure>
</div>
<div id="Inner">
<div id="Container" >
<div id="Head">
<div id="Head_left">
<div id="Leaf_top"><img src="img/shop3.jpg" width="324" /></div>
<div id="Leaf_bottom"> <a class="registration" href="index.php?con=11">REGISTRATION</a> <a class="log-in" href="index.php?con=12">LOG IN</a> </div>
</div>
<div id="Head_right">
<div id="Logo">
<div id="Name"><span class="blue">I</span><span class="purple">n</span>&nbsp;<span class="blue">S</span><span class="purple">tyle</span> </div>
<div id="Informations">Latest trends in Fashion</div>
</div>
<div id="Top_menu"> <a class="kart" href="?page=home"><span>KART</span></a> 
<a class="video" href="video.html"><span>VIDEO</span></a>
<a class="contact" href="index.php?con=1"><span>CONTACT</span></a>
<a class="help" href="about_us.html"><span>ABOUT US</span></a>
<a class="home" href="?page=home"><span>HOME</span></a>
</div>
</div>
</div>
<div id="CentralPart">
<div id="LeftPart">
<div id="Menu">
<div id="Menu_header">
<div class="menu_header_left"> <span class="menu_text"><font face="Georgia, Times New Roman, Times, serif">Search</font></span>
</div>
<div class="menu_header_right"> </div>
<div id="Menu_content"> <!--<a class="menu_item" href="?page=home"><span>--><!-- Start of Page Search -->

		
		    <h5>&nbsp;</h5>
			<form method="post">
		    <input type="text" name="t1" value="search" onfocus="if(this.value=='search'){this.value='';}"onBlur="if(this.value==''){this.value='search';}"/>
            <input name="sear" type="submit" class="button" id="sub" value="Go" />
</form>
<?php
	if($_REQUEST['sear'])
	  {
	   $se=$_REQUEST['t1'];
	   if($se!=NULL)
	   {
	   echo "<script>location.href='index.php?se=$se'</script>";
	   }
        }
		?>
		

		  <h5>&nbsp;</h5>
		  <!--</form>-->
		

		<!-- End of Page Search --></span></a><br>
</div>
<div class="menu_header_left"> <span class="menu_text">MEN</span>
</div>
<div class="menu_header_right"> </div>
</div>
<div id="Menu_content"> <a class="menu_item" href="index.php?catg=1 & subcatg=ANTI_AGING"><span>ANTI_AGING</span></a><br>
<a class="menu_item" href="index.php?catg=1 & subcatg=CLEANSER"><span>CLEANSER</span></a><br>
<a class="menu_item" href="index.php?catg=1 & subcatg=PRE_SHAVE"><span>PRE_SHAVE</span></a><br>
<a class="menu_item" href="index.php?catg=1 & subcatg=SHAVE"><span>SHAVE</span></a><br>
<a class="menu_item" href="index.php?catg=1 & subcatg=BODY_PRODUCT"><span>BODY_PRODUCT</span></a><br>
<a class="menu_item" href="index.php?catg=1 & subcatg=HAIR_PRODUCT"><span>HAIR_PRODUCT</span></a><br>

</div>

<div class="menu_header_left"> <span class="menu_text">WOMEN</span>
</div>
<div class="menu_header_right"> </div>
<div id="Menu_content"> <a class="menu_item" href="index.php?catg=2 & subcatg=MOISTURIZER"><span>MOISTURIZER</span></a><br>
<a class="menu_item" href="index.php?catg=2 & subcatg=PRIMER"><span>PRIMER</span></a><br>
<a class="menu_item" href="index.php?catg=2 & subcatg=CONCEALER"><span>CONCEALER</span></a><br>
<a class="menu_item" href="index.php?catg=2 & subcatg=FOUNDATION"><span>FOUNDATION</span></a><br>
<a class="menu_item" href="index.php?catg=2 & subcatg=EYEBROW_POMADE"><span>EYEBROW_POMADE</span></a><br>
<a class="menu_item" href="index.php?catg=2 & subcatg=SPOOLIE_BRUSH"><span>SPOOLIE BRUSH</span></a><br>
<a class="menu_item" href="index.php?catg=2 & subcatg=EYELINER"><span>EYELINER</span></a><br>
<a class="menu_item" href="index.php?catg=2 & subcatg=MASCARA"><span>MASCARA</span></a><br>
<a class="menu_item" href="index.php?catg=2 & subcatg=LIPSTICK"><span>LIPSTICK</span></a><br>
<a class="menu_item" href="index.php?catg=2 & subcatg=BLUSH_HIGHLIGHTER"><span>BLUSH_HIGHLIGHTER</span></a><br>
<a class="menu_item" href="index.php?catg=2 & subcatg=EYESHADOW_PALETTE"><span>EYESHADOW_PALETTE</span></a><br>
</div>

<div class="menu_header_left"> <span class="menu_text">KIDS</span>
</div>
<div class="menu_header_right"> </div>
<div id="Menu_content"> <a class="menu_item" href="index.php?catg=3 & subcatg=LOTION"><span>LOTION</span></a><br>
<a class="menu_item" href="index.php?catg=3 & subcatg=CREAM"><span>CREAM</span></a><br>
<a class="menu_item" href="index.php?catg=3 & subcatg=POWDER_SOAP"><span>POWDER & SOAP</span></a><br>
<a class="menu_item" href="index.php?catg=3 & subcatg=OIL_SHAMPOO"><span>OIL & SHAMPOO</span></a><br>

</div>
</div>
<img src="usepics/4.jpg" width="228" height="183" /></div>

<div id="RightPart">
<?php
  if($_REQUEST['se'])
	    {
		include("search.php");
		}
if($_REQUEST['con']==1)
{
include("contact.php");
}
if($_REQUEST['con']==2)
{
include("about.php");
}
if($_REQUEST['con']==3)
{
include("gallery.php");
}
if($_REQUEST['con']==11)
 {
	include("register.php");
	 }
	if($_REQUEST['con']==12)
 {
	include("login.php");
	 }
	
		if($_REQUEST['con']==13)
 {
	include("welcome.php");
	 }
		if($_REQUEST['con']==14)
 {
	include("viewitem.php");
	 }

if(!($_REQUEST['catg'])and !($_REQUEST['con'])and !($_REQUEST['se']))
{
include("home.php");
}

if($_REQUEST['catg']==1)
{
if($_REQUEST['subcatg']=='ANTI_AGING')
{
include("ANTI_AGING.php");
}
}
if($_REQUEST['catg']==1)
{
if($_REQUEST['subcatg']=='CLEANSER')
{
include("CLEANSER.php");
}
}
if($_REQUEST['catg']==1)
{
if($_REQUEST['subcatg']=='PRE_SHAVE')
{
include("PRE_SHAVE.php");
}
}
if($_REQUEST['catg']==1)
{
if($_REQUEST['subcatg']=='SHAVE')
{
include("SHAVE.php");
}
}
if($_REQUEST['catg']==1)
{
if($_REQUEST['subcatg']=='BODY_PRODUCT')
{
include("BODY_PRODUCT.php");
}
}
if($_REQUEST['catg']==1)
{
if($_REQUEST['subcatg']=='HAIR_PRODUCT')
{
include("HAIR_PRODUCT.php");
}
}

if($_REQUEST['catg']==2)
{
if($_REQUEST['subcatg']=='MOISTURIZER')
{
include("MOISTURIZER.php");
}
}
if($_REQUEST['catg']==2)
{
if($_REQUEST['subcatg']=='PRIMER')
{
include("PRIMER.php");
}
}
if($_REQUEST['catg']==2)
{
if($_REQUEST['subcatg']=='CONCEALER')
{
include("CONCEALER.php");
}
}
if($_REQUEST['catg']==2)
{
if($_REQUEST['subcatg']=='FOUNDATION')
{
include("FOUNDATION.php");
}
}
if($_REQUEST['catg']==2)
{
if($_REQUEST['subcatg']=='EYEBROW_POMADE')
{
include("EYEBROW_POMADE.php");
}
}
if($_REQUEST['catg']==2)
{
if($_REQUEST['subcatg']=='SPOOLIE BRUSH')
{
include("SPOOLIE_BRUSH.php");
}
}
if($_REQUEST['catg']==2)
{
if($_REQUEST['subcatg']=='EYELINER')
{
include("EYELINER.php");
}
}
if($_REQUEST['catg']==2)
{
if($_REQUEST['subcatg']=='MASCARA')
{
include("MASCARA.php");
}
}
if($_REQUEST['catg']==2)
{
if($_REQUEST['subcatg']=='LIPSTICK')
{
include("LIPSTICK.php");
}
}
if($_REQUEST['catg']==2)
{
if($_REQUEST['subcatg']=='BLUSH_HIGHLIGHTER')
{
include("BLUSH_HIGHLIGHTER.php");
}
}
if($_REQUEST['catg']==2)
{
if($_REQUEST['subcatg']=='EYESHADOW_PALETTE')
{
include("EYESHADOW_PALETTE.php");
}
}
if($_REQUEST['catg']==3)
{
if($_REQUEST['subcatg']=='LOTION')
{
include("LOTION.php");
}
}
if($_REQUEST['catg']==3)
{
if($_REQUEST['subcatg']=='CREAM')
{
include("CREAM.php");
}
}
if($_REQUEST['catg']==3)
{
if($_REQUEST['subcatg']=='POWDER_SOAP')
{
include("POWDER.php");
}
}
if($_REQUEST['catg']==3)
{
if($_REQUEST['subcatg']=='OIL_SHAMPOO')
{
include("OIL.php");
}
}
?>

</div>
<div class="cleaner"></div>
</div>
<div id="Bottom">
<p class="down"><b>Copyright &copy; IN STYLE, Design by:Faiza omer & Sayeeda Saima Tulon</b></p>

</div>
</div>
</div>
</div>
</div>


</body></html>