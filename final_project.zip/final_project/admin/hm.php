<body>
<br /><br />
<center><font color="#993399" size="+3" face="Georgia, Times New Roman, Times, serif">Welcome User</font><br/><br>
<font color="#CC3366" size="+3" face="Georgia, Times New Roman, Times, serif">You are in the IN STYLE.</font><br/><br>
<font color="#003333" size="+2">You are Successfully logged in!!! </font><br/><br/>
</center>

</body>